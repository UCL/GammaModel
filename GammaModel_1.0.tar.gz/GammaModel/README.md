
# Modelling age-at-death profiles using the Gamma distribution

R package created to accompany the 2018 Journal of Archaeological Science paper 'Modelling caprine age-at-death profiles using the Gamma distribution' by Adrian Timpson, Rosalind E Gillis, Katie Manning and Mark G Thomas.

Please contact a.timpson@ucl.ac.uk  in the first instance to make suggestions, report bugs or request help.

